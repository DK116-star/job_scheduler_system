const express = require("express");
const axios = require("axios");
const db = require("../db");

const router = express.Router();

/* CREATE JOB */
router.post("/", (req, res) => {
  const { taskName, payload, priority } = req.body;

  const sql = "INSERT INTO jobs (taskName, payload, priority) VALUES (?, ?, ?)";
  db.query(sql, [taskName, JSON.stringify(payload), priority], (err, result) => {
    if (err) return res.status(500).json(err);
    res.json({ message: "Job Created", id: result.insertId });
  });
});

/* LIST JOBS */
router.get("/", (req, res) => {
  db.query("SELECT * FROM jobs", (err, rows) => {
    if (err) return res.status(500).json(err);
    res.json(rows);
  });
});

/* JOB DETAIL */
router.get("/:id", (req, res) => {
  db.query("SELECT * FROM jobs WHERE id=?", [req.params.id], (err, rows) => {
    if (err) return res.status(500).json(err);
    res.json(rows[0]);
  });
});

/* RUN JOB */
router.post("/run-job/:id", (req, res) => {
  const jobId = req.params.id;

  db.query(
  "UPDATE jobs SET status='running' WHERE id=?",
  [jobId],
  (err) => {
    if (err) return res.status(500).json(err);
  }
);


  setTimeout(() => {
    db.query("UPDATE jobs SET status='completed' WHERE id=?", [jobId]);

    db.query("SELECT * FROM jobs WHERE id=?", [jobId], async (err, rows) => {
      const job = rows[0];

      await axios.post("https://httpbin.org/post", {
        jobId: job.id,
        taskName: job.taskName,
        priority: job.priority,
        payload: job.payload,
        completedAt: new Date()
      });
    });
  }, 3000);

  res.json({ message: "Job started" });
});

module.exports = router;
