export const metadata = {
  title: "Job Scheduler",
  description: "Job Scheduler App",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
