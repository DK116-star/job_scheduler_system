"use client";

import { useEffect, useState } from "react";
import axios from "axios";

type Job = {
  id: number;
  taskName: string;
  priority: string;
  status: string;
};

export default function Home() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [taskName, setTaskName] = useState("");
  const [priority, setPriority] = useState("Low");

  // 🔹 Fetch jobs
  const fetchJobs = async () => {
    const res = await axios.get("http://localhost:5000/api/jobs");
    setJobs(res.data);
  };

  // 🔹 Create job
  const createJob = async () => {
    if (!taskName) {
      alert("Enter task name");
      return;
    }

    await axios.post("http://localhost:5000/api/jobs", {
      taskName,
      payload: { source: "UI" },
      priority
    });

    setTaskName("");
    fetchJobs();
  };

  // 🔹 Run job
  const runJob = async (id: number) => {
    await axios.post(`http://localhost:5000/api/jobs/run-job/${id}`);
    fetchJobs();
  };

  // 🔹 Auto refresh jobs
  useEffect(() => {
    fetchJobs();
    const interval = setInterval(fetchJobs, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div style={{ padding: 20, maxWidth: 700 }}>
      <h1>Job Scheduler</h1>

      {/* Create Job */}
      <div style={{ marginBottom: 20 }}>
        <input
          placeholder="Task Name"
          value={taskName}
          onChange={(e) => setTaskName(e.target.value)}
          style={{ marginRight: 10 }}
        />

        <select
          value={priority}
          onChange={(e) => setPriority(e.target.value)}
          style={{ marginRight: 10 }}
        >
          <option>Low</option>
          <option>Medium</option>
          <option>High</option>
        </select>

        <button onClick={createJob}>Create Job</button>
      </div>

      {/* Job List */}
      {jobs.map((job) => (
        <div
          key={job.id}
          style={{
            border: "1px solid #ccc",
            padding: 12,
            marginBottom: 10
          }}
        >
          <p><b>Task:</b> {job.taskName}</p>
          <p><b>Priority:</b> {job.priority}</p>
          <p><b>Status:</b> {job.status}</p>

          <button
            onClick={() => runJob(job.id)}
            disabled={job.status !== "pending"}
          >
            Run Job
          </button>
        </div>
      ))}
    </div>
  );
}
